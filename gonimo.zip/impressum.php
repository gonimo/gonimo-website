<?php
require_once 'header.php';
?>

<title>Gonimo-Impressum</title>
<div class="container">
<p>
Impressum ala Gesetz.
</p>
</div>

<?php include 'footer.php'; ?>