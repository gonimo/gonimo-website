<?php
require_once 'header.php';
?>

<title>Gonimo-Team-Blog</title>
<div class="container">

<div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="http://blog.gonimo.com"></iframe>
</div>
</div>

<?php include 'footer.php'; ?>