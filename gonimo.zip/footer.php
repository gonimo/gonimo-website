<footer class="footer">
<div class="container">
<div class="row row-footer">
<div class="col-xs-4">
<a href="agb.php" title="AGB"> AGB </a>
</div>
<div class="col-xs-4">
<a href="impressum.php" title="Impressum"> Impressum </a> 
</div>
<div class="col-xs-4">
<a href="kontakt.php" title="Kontakt"> Kontakt </a>
</div>
<div class="col-xs-12">
copyright: gonimo/ninjagulbi 2016 - <?php echo date("Y"); ?>
</div>
</div>
</div>
</footer>


</body>
</html>